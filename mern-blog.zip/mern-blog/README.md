# MERN Blog

A full-stack blog application built with MongoDB, Express, React (Vite), and Node.js. Includes JWT authentication, post & comment CRUD, and a security-hardened Express API.

## Project structure

```
mern-blog/
├── client/          # React (Vite) frontend
├── server/          # Express + MongoDB backend
└── docker-compose.yml
```

## Features

- User registration/login with JWT auth (passwords hashed with bcrypt)
- Create, read, update, delete blog posts (author-only edit/delete)
- Comments on posts (author-only delete)
- Paginated post list with full-text search
- Profile editing
- Security middleware: Helmet, CORS, rate limiting on auth routes, input validation
- Centralized error handling
- Seed script for sample data
- Jest + Supertest integration tests
- Dockerfiles + docker-compose for local orchestration

## Prerequisites

- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string
- (Optional) Docker + Docker Compose

## 1. Backend setup

```bash
cd server
cp .env.example .env     # then edit MONGO_URI / JWT_SECRET as needed
npm install
npm run seed              # optional: populate sample users/posts/comments
npm run dev                # starts on http://localhost:5000
```

Sample seeded accounts (if you ran `npm run seed`):
- alice@example.com / password123
- bob@example.com / password123

## 2. Frontend setup

In a new terminal:

```bash
cd client
cp .env.example .env
npm install
npm run dev                # starts on http://localhost:5173
```

Vite is configured to proxy `/api` requests to `http://localhost:5000`, so the two dev servers work together out of the box.

## 3. Running with Docker Compose

From the project root:

```bash
JWT_SECRET=your_secret_here docker-compose up --build
```

This spins up MongoDB, the Express API (port 5000), and the built React app served via Nginx (port 3000).

## 4. Running tests

```bash
cd server
# point MONGO_URI in .env at a disposable test database first
npm test
```

## API overview

| Method | Route                          | Access   | Description                |
|--------|---------------------------------|----------|-----------------------------|
| POST   | /api/auth/register              | Public   | Register a new user         |
| POST   | /api/auth/login                 | Public   | Log in, receive JWT         |
| GET    | /api/auth/me                    | Private  | Get current user            |
| GET    | /api/users/:id                  | Public   | Get public user profile     |
| PUT    | /api/users/me                   | Private  | Update own profile          |
| GET    | /api/posts                      | Public   | List posts (paginated/search)|
| POST   | /api/posts                      | Private  | Create a post                |
| GET    | /api/posts/:id                  | Public   | Get a single post            |
| PUT    | /api/posts/:id                  | Private  | Update own post              |
| DELETE | /api/posts/:id                  | Private  | Delete own post              |
| GET    | /api/posts/:postId/comments     | Public   | List comments on a post      |
| POST   | /api/posts/:postId/comments     | Private  | Add a comment                |
| DELETE | /api/comments/:id                | Private  | Delete own comment           |

## Next steps / suggested extensions

- Add image upload for post cover images and avatars (e.g. via S3 or Cloudinary)
- Add role-based admin dashboard for moderating posts/comments
- Add password reset flow (email token)
- Add CI pipeline (GitHub Actions) running lint + tests on push
