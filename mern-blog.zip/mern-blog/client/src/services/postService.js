import api from './api';

export async function getPosts({ page = 1, limit = 10, search = '' } = {}) {
  const { data } = await api.get('/posts', { params: { page, limit, search } });
  return data;
}

export async function getPost(id) {
  const { data } = await api.get(`/posts/${id}`);
  return data;
}

export async function createPost(payload) {
  const { data } = await api.post('/posts', payload);
  return data;
}

export async function updatePost(id, payload) {
  const { data } = await api.put(`/posts/${id}`, payload);
  return data;
}

export async function deletePost(id) {
  const { data } = await api.delete(`/posts/${id}`);
  return data;
}

export async function getComments(postId) {
  const { data } = await api.get(`/posts/${postId}/comments`);
  return data;
}

export async function addComment(postId, content) {
  const { data } = await api.post(`/posts/${postId}/comments`, { content });
  return data;
}

export async function deleteComment(commentId) {
  const { data } = await api.delete(`/comments/${commentId}`);
  return data;
}
