import React from 'react';
import { Link } from 'react-router-dom';

export default function PostCard({ post }) {
  const preview =
    post.content.length > 180 ? `${post.content.slice(0, 180)}...` : post.content;

  return (
    <div className="card">
      <h3>
        <Link to={`/posts/${post._id}`}>{post.title}</Link>
      </h3>
      <p className="muted">
        by {post.author?.username || 'unknown'} ·{' '}
        {new Date(post.createdAt).toLocaleDateString()}
      </p>
      <p>{preview}</p>
      {post.tags?.length > 0 && (
        <p className="muted">{post.tags.map((t) => `#${t}`).join(' ')}</p>
      )}
    </div>
  );
}
