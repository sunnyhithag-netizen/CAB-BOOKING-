import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { addComment, deleteComment } from '../services/postService';

export default function CommentList({ postId, comments, onCommentsChange }) {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    setSubmitting(true);
    setError('');
    try {
      const data = await addComment(postId, content.trim());
      onCommentsChange([data.comment, ...comments]);
      setContent('');
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (commentId) => {
    try {
      await deleteComment(commentId);
      onCommentsChange(comments.filter((c) => c._id !== commentId));
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to delete comment');
    }
  };

  return (
    <div>
      <h3>Comments ({comments.length})</h3>

      {user ? (
        <form onSubmit={handleSubmit} style={{ marginBottom: '1.5rem' }}>
          {error && <p className="error-text">{error}</p>}
          <textarea
            className="input"
            rows={3}
            placeholder="Add a comment..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <button className="btn" type="submit" disabled={submitting}>
            {submitting ? 'Posting...' : 'Post Comment'}
          </button>
        </form>
      ) : (
        <p className="muted">Log in to leave a comment.</p>
      )}

      {comments.map((c) => (
        <div className="card" key={c._id}>
          <p className="muted">
            {c.author?.username || 'unknown'} ·{' '}
            {new Date(c.createdAt).toLocaleDateString()}
          </p>
          <p>{c.content}</p>
          {user && (user._id === c.author?._id || user.role === 'admin') && (
            <button className="btn danger" onClick={() => handleDelete(c._id)}>
              Delete
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
