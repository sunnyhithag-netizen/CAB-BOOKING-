import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <Link to="/" style={{ fontWeight: 700, fontSize: '1.1rem' }}>
        MERN Blog
      </Link>
      <div className="links">
        <Link to="/">Posts</Link>
        {user ? (
          <>
            <Link to="/posts/new">New Post</Link>
            <Link to="/profile">{user.username}</Link>
            <button className="btn secondary" onClick={handleLogout}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">
              <button className="btn">Sign Up</button>
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
