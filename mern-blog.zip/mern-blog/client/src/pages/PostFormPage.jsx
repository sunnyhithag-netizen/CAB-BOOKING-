import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getPost, createPost, updatePost } from '../services/postService';

export default function PostFormPage() {
  const { id } = useParams(); // present only when editing
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const [form, setForm] = useState({ title: '', content: '', tags: '' });
  const [loading, setLoading] = useState(isEditing);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isEditing) return;
    getPost(id)
      .then((data) => {
        setForm({
          title: data.post.title,
          content: data.post.content,
          tags: (data.post.tags || []).join(', '),
        });
      })
      .catch(() => setError('Failed to load post'))
      .finally(() => setLoading(false));
  }, [id, isEditing]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    const payload = {
      title: form.title,
      content: form.content,
      tags: form.tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean),
    };

    try {
      if (isEditing) {
        await updatePost(id, payload);
        navigate(`/posts/${id}`);
      } else {
        const data = await createPost(payload);
        navigate(`/posts/${data.post._id}`);
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to save post');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <p className="container">Loading...</p>;

  return (
    <div className="container" style={{ maxWidth: 600 }}>
      <h2>{isEditing ? 'Edit Post' : 'New Post'}</h2>
      {error && <p className="error-text">{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          className="input"
          name="title"
          placeholder="Title"
          value={form.title}
          onChange={handleChange}
          required
          maxLength={150}
        />
        <textarea
          className="input"
          name="content"
          placeholder="Write your post..."
          rows={10}
          value={form.content}
          onChange={handleChange}
          required
        />
        <input
          className="input"
          name="tags"
          placeholder="Tags (comma-separated)"
          value={form.tags}
          onChange={handleChange}
        />
        <button className="btn" type="submit" disabled={submitting}>
          {submitting ? 'Saving...' : isEditing ? 'Update Post' : 'Publish Post'}
        </button>
      </form>
    </div>
  );
}
