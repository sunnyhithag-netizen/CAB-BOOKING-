import React, { useEffect, useState } from 'react';
import PostCard from '../components/PostCard.jsx';
import { getPosts } from '../services/postService';

export default function PostsListPage() {
  const [posts, setPosts] = useState([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let ignore = false;
    setLoading(true);
    getPosts({ page, search })
      .then((data) => {
        if (ignore) return;
        setPosts(data.posts);
        setPages(data.pages);
      })
      .catch(() => !ignore && setError('Failed to load posts'))
      .finally(() => !ignore && setLoading(false));
    return () => {
      ignore = true;
    };
  }, [page, search]);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    setSearch(e.target.elements.search.value);
  };

  return (
    <div className="container">
      <form onSubmit={handleSearch} style={{ marginBottom: '1.5rem' }}>
        <input className="input" name="search" placeholder="Search posts..." defaultValue={search} />
      </form>

      {loading && <p>Loading posts...</p>}
      {error && <p className="error-text">{error}</p>}
      {!loading && posts.length === 0 && <p className="muted">No posts found.</p>}

      {posts.map((post) => (
        <PostCard key={post._id} post={post} />
      ))}

      {pages > 1 && (
        <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
          <button className="btn secondary" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Previous
          </button>
          <span className="muted">
            Page {page} of {pages}
          </span>
          <button className="btn secondary" disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>
            Next
          </button>
        </div>
      )}
    </div>
  );
}
