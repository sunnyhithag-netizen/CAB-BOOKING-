import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import api from '../services/api';

export default function ProfilePage() {
  const { user } = useAuth();
  const [form, setForm] = useState({ username: user?.username || '', bio: user?.bio || '' });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    setMessage('');
    try {
      await api.put('/users/me', form);
      setMessage('Profile updated successfully');
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to update profile');
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) return null;

  return (
    <div className="container" style={{ maxWidth: 500 }}>
      <h2>My Profile</h2>
      <p className="muted">{user.email}</p>
      {message && <p style={{ color: 'green' }}>{message}</p>}
      {error && <p className="error-text">{error}</p>}
      <form onSubmit={handleSubmit}>
        <input
          className="input"
          name="username"
          value={form.username}
          onChange={handleChange}
          required
          minLength={3}
        />
        <textarea
          className="input"
          name="bio"
          rows={4}
          placeholder="Tell us about yourself..."
          value={form.bio}
          onChange={handleChange}
          maxLength={300}
        />
        <button className="btn" type="submit" disabled={submitting}>
          {submitting ? 'Saving...' : 'Save Changes'}
        </button>
      </form>
    </div>
  );
}
