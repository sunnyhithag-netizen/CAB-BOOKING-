import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import CommentList from '../components/CommentList.jsx';
import { getPost, getComments, deletePost } from '../services/postService';

export default function PostDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let ignore = false;
    setLoading(true);
    Promise.all([getPost(id), getComments(id)])
      .then(([postData, commentData]) => {
        if (ignore) return;
        setPost(postData.post);
        setComments(commentData.comments);
      })
      .catch(() => !ignore && setError('Post not found'))
      .finally(() => !ignore && setLoading(false));
    return () => {
      ignore = true;
    };
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Delete this post? This cannot be undone.')) return;
    try {
      await deletePost(id);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to delete post');
    }
  };

  if (loading) return <p className="container">Loading...</p>;
  if (error) return <p className="container error-text">{error}</p>;
  if (!post) return null;

  const canEdit = user && (user._id === post.author?._id || user.role === 'admin');

  return (
    <div className="container">
      <h1>{post.title}</h1>
      <p className="muted">
        by {post.author?.username} · {new Date(post.createdAt).toLocaleDateString()}
      </p>
      {post.tags?.length > 0 && (
        <p className="muted">{post.tags.map((t) => `#${t}`).join(' ')}</p>
      )}
      <div style={{ whiteSpace: 'pre-wrap', margin: '1.5rem 0' }}>{post.content}</div>

      {canEdit && (
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
          <Link to={`/posts/${id}/edit`}>
            <button className="btn secondary">Edit</button>
          </Link>
          <button className="btn danger" onClick={handleDelete}>
            Delete
          </button>
        </div>
      )}

      <hr />
      <CommentList postId={id} comments={comments} onCommentsChange={setComments} />
    </div>
  );
}
