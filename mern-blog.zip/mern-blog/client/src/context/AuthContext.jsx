import React, { createContext, useContext, useEffect, useReducer } from 'react';
import { loginUser, registerUser, fetchCurrentUser } from '../services/authService';

const AuthContext = createContext(null);

const initialState = {
  user: null,
  token: localStorage.getItem('token') || null,
  loading: true, // true until we've checked for an existing session
  error: null,
};

function authReducer(state, action) {
  switch (action.type) {
    case 'AUTH_START':
      return { ...state, loading: true, error: null };
    case 'AUTH_SUCCESS':
      return { ...state, loading: false, user: action.payload.user, token: action.payload.token, error: null };
    case 'AUTH_FAIL':
      return { ...state, loading: false, error: action.payload };
    case 'LOGOUT':
      return { ...state, user: null, token: null, loading: false, error: null };
    case 'STOP_LOADING':
      return { ...state, loading: false };
    default:
      return state;
  }
}

export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // On mount, if a token exists, verify it and load the user
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      dispatch({ type: 'STOP_LOADING' });
      return;
    }
    fetchCurrentUser()
      .then((data) => dispatch({ type: 'AUTH_SUCCESS', payload: { user: data.user, token } }))
      .catch(() => {
        localStorage.removeItem('token');
        dispatch({ type: 'STOP_LOADING' });
      });
  }, []);

  const login = async (credentials) => {
    dispatch({ type: 'AUTH_START' });
    try {
      const data = await loginUser(credentials);
      localStorage.setItem('token', data.token);
      dispatch({ type: 'AUTH_SUCCESS', payload: data });
      return data;
    } catch (err) {
      const message = err.response?.data?.error || 'Login failed';
      dispatch({ type: 'AUTH_FAIL', payload: message });
      throw new Error(message);
    }
  };

  const register = async (payload) => {
    dispatch({ type: 'AUTH_START' });
    try {
      const data = await registerUser(payload);
      localStorage.setItem('token', data.token);
      dispatch({ type: 'AUTH_SUCCESS', payload: data });
      return data;
    } catch (err) {
      const message = err.response?.data?.error || 'Registration failed';
      dispatch({ type: 'AUTH_FAIL', payload: message });
      throw new Error(message);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    dispatch({ type: 'LOGOUT' });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
