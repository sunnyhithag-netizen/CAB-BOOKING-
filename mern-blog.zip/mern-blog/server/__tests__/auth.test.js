/**
 * Integration tests for auth endpoints.
 * Requires a running MongoDB instance reachable via MONGO_URI (use a
 * dedicated test database, e.g. mongodb://127.0.0.1:27017/mern-blog-test).
 */
const request = require('supertest');
const mongoose = require('mongoose');
require('dotenv').config();

const app = require('../index');
const User = require('../models/User');

beforeAll(async () => {
  // index.js already connects to Mongo on import; wait for it to be ready
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(process.env.MONGO_URI);
  }
});

afterEach(async () => {
  await User.deleteMany();
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('POST /api/auth/register', () => {
  it('registers a new user and returns a token', async () => {
    const res = await request(app).post('/api/auth/register').send({
      username: 'testuser',
      email: 'testuser@example.com',
      password: 'password123',
    });

    expect(res.statusCode).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.email).toBe('testuser@example.com');
    expect(res.body.user.password).toBeUndefined();
  });

  it('rejects duplicate emails', async () => {
    await User.create({
      username: 'existing',
      email: 'dupe@example.com',
      password: 'password123',
    });

    const res = await request(app).post('/api/auth/register').send({
      username: 'newuser',
      email: 'dupe@example.com',
      password: 'password123',
    });

    expect(res.statusCode).toBe(409);
  });
});

describe('POST /api/auth/login', () => {
  it('logs in with correct credentials', async () => {
    await request(app).post('/api/auth/register').send({
      username: 'loginuser',
      email: 'login@example.com',
      password: 'password123',
    });

    const res = await request(app).post('/api/auth/login').send({
      email: 'login@example.com',
      password: 'password123',
    });

    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  it('rejects incorrect password', async () => {
    await request(app).post('/api/auth/register').send({
      username: 'wrongpass',
      email: 'wrongpass@example.com',
      password: 'password123',
    });

    const res = await request(app).post('/api/auth/login').send({
      email: 'wrongpass@example.com',
      password: 'wrongpassword',
    });

    expect(res.statusCode).toBe(401);
  });
});
