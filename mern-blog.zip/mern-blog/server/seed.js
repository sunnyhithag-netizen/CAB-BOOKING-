/**
 * Seeds the database with sample users, posts, and comments.
 * Usage: node seed.js
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Post = require('./models/Post');
const Comment = require('./models/Comment');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding...');

    await Promise.all([User.deleteMany(), Post.deleteMany(), Comment.deleteMany()]);
    console.log('Cleared existing data');

    const alice = await User.create({
      username: 'alice',
      email: 'alice@example.com',
      password: 'password123',
      bio: 'Full-stack developer and coffee enthusiast.',
    });

    const bob = await User.create({
      username: 'bob',
      email: 'bob@example.com',
      password: 'password123',
      bio: 'Writes about JavaScript and web performance.',
    });

    const post1 = await Post.create({
      author: alice._id,
      title: 'Getting Started with the MERN Stack',
      content:
        'The MERN stack combines MongoDB, Express, React, and Node.js into a single JavaScript-powered workflow...',
      tags: ['mern', 'javascript', 'tutorial'],
    });

    const post2 = await Post.create({
      author: bob._id,
      title: 'Why I Switched from CRA to Vite',
      content:
        'Vite offers near-instant hot module replacement and a much faster build pipeline compared to Create React App...',
      tags: ['vite', 'react', 'tooling'],
    });

    await Comment.create({
      post: post1._id,
      author: bob._id,
      content: 'Great intro! This helped me understand the architecture.',
    });

    await Comment.create({
      post: post2._id,
      author: alice._id,
      content: 'Totally agree, Vite has been a game changer for our team.',
    });

    console.log('Seed data created successfully');
    process.exit(0);
  } catch (err) {
    console.error('Seeding error:', err);
    process.exit(1);
  }
};

seed();
