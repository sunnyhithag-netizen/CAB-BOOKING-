const Post = require('../models/Post');
const Comment = require('../models/Comment');
const ApiError = require('../utils/ApiError');

// @desc    Get all posts (paginated, optional search)
// @route   GET /api/posts?page=1&limit=10&search=term
// @access  Public
exports.getPosts = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const filter = { published: true };
    if (req.query.search) {
      filter.$text = { $search: req.query.search };
    }
    if (req.query.author) {
      filter.author = req.query.author;
    }

    const [posts, total] = await Promise.all([
      Post.find(filter)
        .populate('author', 'username avatar')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Post.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      count: posts.length,
      total,
      page,
      pages: Math.ceil(total / limit),
      posts,
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single post by id
// @route   GET /api/posts/:id
// @access  Public
exports.getPost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'username avatar bio');
    if (!post) throw new ApiError(404, 'Post not found');
    res.status(200).json({ success: true, post });
  } catch (err) {
    next(err);
  }
};

// @desc    Create a post
// @route   POST /api/posts
// @access  Private
exports.createPost = async (req, res, next) => {
  try {
    const { title, content, coverImage, tags } = req.body;
    if (!title || !content) {
      throw new ApiError(400, 'Title and content are required');
    }

    const post = await Post.create({
      title,
      content,
      coverImage,
      tags,
      author: req.user._id,
    });

    const populated = await post.populate('author', 'username avatar');

    res.status(201).json({ success: true, post: populated });
  } catch (err) {
    next(err);
  }
};

// @desc    Update a post (author only)
// @route   PUT /api/posts/:id
// @access  Private
exports.updatePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) throw new ApiError(404, 'Post not found');

    if (post.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      throw new ApiError(403, 'You are not authorized to edit this post');
    }

    const allowedFields = ['title', 'content', 'coverImage', 'tags', 'published'];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) post[field] = req.body[field];
    });

    await post.save();
    res.status(200).json({ success: true, post });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete a post (author or admin only)
// @route   DELETE /api/posts/:id
// @access  Private
exports.deletePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) throw new ApiError(404, 'Post not found');

    if (post.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      throw new ApiError(403, 'You are not authorized to delete this post');
    }

    await Comment.deleteMany({ post: post._id });
    await post.deleteOne();

    res.status(200).json({ success: true, message: 'Post deleted' });
  } catch (err) {
    next(err);
  }
};
