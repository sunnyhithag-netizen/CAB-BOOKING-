const User = require('../models/User');
const ApiError = require('../utils/ApiError');

// @desc    Get logged-in user's profile
// @route   GET /api/users/me
// @access  Private
exports.getProfile = async (req, res, next) => {
  try {
    res.status(200).json({ success: true, user: req.user });
  } catch (err) {
    next(err);
  }
};

// @desc    Update logged-in user's profile
// @route   PUT /api/users/me
// @access  Private
exports.updateProfile = async (req, res, next) => {
  try {
    const allowedFields = ['username', 'bio', 'avatar'];
    const updates = {};
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const user = await User.findByIdAndUpdate(req.user._id, updates, {
      new: true,
      runValidators: true,
    });

    if (!user) throw new ApiError(404, 'User not found');

    res.status(200).json({ success: true, user });
  } catch (err) {
    next(err);
  }
};

// @desc    Get a public user profile by id
// @route   GET /api/users/:id
// @access  Public
exports.getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) throw new ApiError(404, 'User not found');
    res.status(200).json({ success: true, user });
  } catch (err) {
    next(err);
  }
};
