const Comment = require('../models/Comment');
const Post = require('../models/Post');
const ApiError = require('../utils/ApiError');

// @desc    Get all comments for a post
// @route   GET /api/posts/:postId/comments
// @access  Public
exports.getCommentsByPost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.postId);
    if (!post) throw new ApiError(404, 'Post not found');

    const comments = await Comment.find({ post: req.params.postId })
      .populate('author', 'username avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: comments.length, comments });
  } catch (err) {
    next(err);
  }
};

// @desc    Add a comment to a post
// @route   POST /api/posts/:postId/comments
// @access  Private
exports.createComment = async (req, res, next) => {
  try {
    const { content } = req.body;
    if (!content) throw new ApiError(400, 'Comment content is required');

    const post = await Post.findById(req.params.postId);
    if (!post) throw new ApiError(404, 'Post not found');

    const comment = await Comment.create({
      content,
      post: req.params.postId,
      author: req.user._id,
    });

    const populated = await comment.populate('author', 'username avatar');

    res.status(201).json({ success: true, comment: populated });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete a comment (author or admin only)
// @route   DELETE /api/comments/:id
// @access  Private
exports.deleteComment = async (req, res, next) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) throw new ApiError(404, 'Comment not found');

    if (comment.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      throw new ApiError(403, 'You are not authorized to delete this comment');
    }

    await comment.deleteOne();
    res.status(200).json({ success: true, message: 'Comment deleted' });
  } catch (err) {
    next(err);
  }
};
