const express = require('express');
const { getProfile, updateProfile, getUserById } = require('../controllers/userController');
const { protect } = require('../middlewares/auth');

const router = express.Router();

router.get('/me', protect, getProfile);
router.put('/me', protect, updateProfile);
router.get('/:id', getUserById);

module.exports = router;
