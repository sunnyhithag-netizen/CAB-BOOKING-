const express = require('express');
const {
  getPosts,
  getPost,
  createPost,
  updatePost,
  deletePost,
} = require('../controllers/postController');
const {
  getCommentsByPost,
  createComment,
} = require('../controllers/commentController');
const { protect } = require('../middlewares/auth');

const router = express.Router();

router.get('/', getPosts);
router.post('/', protect, createPost);
router.get('/:id', getPost);
router.put('/:id', protect, updatePost);
router.delete('/:id', protect, deletePost);

// Nested comment routes: /api/posts/:postId/comments
router.get('/:postId/comments', getCommentsByPost);
router.post('/:postId/comments', protect, createComment);

module.exports = router;
